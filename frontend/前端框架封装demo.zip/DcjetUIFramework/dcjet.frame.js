(function(){
var dcjet=window.dcjet;
dcjet={
    initControls:function(){
        if(d.config.control)
        {
            for(var c in d.config.control)
            {
             $(c).textbox(d.config.control[c]);
            }
        }
        $(".dcjet-textbox").textbox();
        $(".dcjet-datetimebox").datetimebox();
        $(".dcjet-numberbox").numberbox();
        $(".dcjet-numberspinner").numberspinner();
        
    }
};
window.d = dcjet;
})(window)
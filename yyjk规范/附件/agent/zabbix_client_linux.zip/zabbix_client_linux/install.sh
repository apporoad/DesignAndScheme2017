mkdir /etc/soft
yum localinstall zabbix-agent-3.4.3-1.el7.x86_64.rpm
yum localinstall zabbix-agent-3.4.3-1.el6.x86_64.rpm